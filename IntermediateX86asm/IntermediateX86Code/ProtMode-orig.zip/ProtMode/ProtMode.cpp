// ProtMode.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "wdbgexts.h"
#include <stdio.h>

PWINDBG_EXTENSION_APIS g_pExtensionApis;
EXT_API_VERSION g_ApiVersion = { 3, 5, EXT_API_VERSION_NUMBER, 0 };

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}

// The initialization function.
VOID WDBGAPI WinDbgExtensionDllInit(
	 PWINDBG_EXTENSION_APIS lpExtensionApis,
	 USHORT usMajorVersion,
	 USHORT usMinorVersion)
{
	 // Save the pointers to the callback functions.
	 g_pExtensionApis = lpExtensionApis;
}
 
// WinDBG calls this to get the extension version.
LPEXT_API_VERSION WDBGAPI ExtensionApiVersion()
{
	return &g_ApiVersion;
}

void DumpGDTOrLDTDescriptor(BOOL bLDT, long lTableIndex)
{
	/////////////////////////////////////////
	// Get the descriptor data.
	/////////////////////////////////////////

	// Get the GDT base address.
	long lTableBase = g_pExtensionApis->lpGetExpressionRoutine(bLDT ? "@LDTR" : "@GDTR");
	
	// Calculate the address of the descriptor we want to dump.
	// Each descriptor is 8 bytes.
	long lDescriptorAddress = lTableBase + 8 * lTableIndex;

	// Copy the descriptor into a buffer that we'll analyze.
	unsigned char Descriptor[8];
	ULONG ulBytesRead;
	g_pExtensionApis->lpReadProcessMemoryRoutine(
		lDescriptorAddress,
		Descriptor,
		8,
		&ulBytesRead);

	/////////////////////////////////////////
	// Print the raw data.
	/////////////////////////////////////////

	g_pExtensionApis->lpOutputRoutine("------------------- Code Segment Descriptor --------------------\r\n");

	// Print out the GDT base, index and resulting descriptor address.
	g_pExtensionApis->lpOutputRoutine("GDT base = 0x%08X, Index = 0x%02x, Descriptor @ 0x%08x\r\n", 
		lTableBase, lTableIndex, lDescriptorAddress);

	// Print out the raw descriptor data.
	g_pExtensionApis->lpOutputRoutine("%08x ", lDescriptorAddress);

	for(int i=0; i<8; i++)
	{
		g_pExtensionApis->lpOutputRoutine("%02x ", Descriptor[i]);
	}
	
	g_pExtensionApis->lpOutputRoutine("\r\n");

	/////////////////////////////////////////
	// Interpret the descriptor.
	/////////////////////////////////////////

	// Parse out the Granularity bit and the Default size bit.
	BOOL b4KBPages = (Descriptor[6] & (1<<7)) == (1<<7);
	BOOL bDefaultSize32 = (Descriptor[6] & (1<<6)) == (1<<6);

	// Print out the interpreted descriptor information.
	g_pExtensionApis->lpOutputRoutine("Segment size is in %s, %s-bit default operand and data size\r\n", 
		b4KBPages ? "4KB pages" : "bytes", bDefaultSize32 ? "32" : "16");
	
	// Parse out the Present, DPL, System bit and S bit.
	BOOL bSegmentPresent = (Descriptor[5] & (1<<7)) == (1<<7);
	char chDPL = (Descriptor[5] >> 5) & 3; 
	BOOL bSystemSegment = (Descriptor[5] & (1<<4)) == 0;
	BOOL bCodeSegment = (Descriptor[5] & (1<<3)) == (1<<3);

	// Print out the interpreted descriptor information.
	g_pExtensionApis->lpOutputRoutine("Segment %s present, DPL = %d, %s segment, %s segment\r\n", 
		bSegmentPresent ? "is" : "is not", 
		chDPL, 
		bSystemSegment ? "System" : "Not system", 
		bCodeSegment ? "Code" : "Data");

	// Parse out the Conforming, Readable and Accessed bits.
	BOOL bConformingSegment = (Descriptor[5] & (1<<2)) == (1<<2);
	BOOL bReadableSegment = (Descriptor[5] & (1<<1)) == (1<<1);
	BOOL bAccessedSegment = (Descriptor[5] & (1<<0)) == (1<<0);

	// Print out the interpreted descriptor information.
	g_pExtensionApis->lpOutputRoutine("Segment is %s, Segment is %s, Segment is %s\r\n", 
		bConformingSegment ? "conforming" : "not conforming", 
		bReadableSegment ? "readable" : "not readable", 
		bAccessedSegment ? "accessed" : "not accessed");

	// Parse out the base address of the code segment.
	unsigned long ulSegmentBaseAddress = (Descriptor[7] << 3*8) + 
		(Descriptor[4] << 2*8) + (Descriptor[3] << 1*8) + Descriptor[2];
	g_pExtensionApis->lpOutputRoutine("Target code segment base address = 0x%08x\r\n", 
		ulSegmentBaseAddress);
	
	// Parse out the segment size.
	unsigned long ulSegmentSize = ((Descriptor[6] & 0xf) << 16) + (Descriptor[1] << 8) + Descriptor[0];
	g_pExtensionApis->lpOutputRoutine("Target code segment size = 0x%08x\r\n", ulSegmentSize);

}

void DumpIDTDescriptor(long lTableIndex)
{
	/////////////////////////////////////////
	// Get the descriptor data.
	/////////////////////////////////////////

	// Get the IDT base address.
	long lTableBase = g_pExtensionApis->lpGetExpressionRoutine("@IDTR");
	
	// Calculate the address of the descriptor we want to dump.
	// Each descriptor is 8 bytes.
	long lDescriptorAddress = lTableBase + 8 * lTableIndex;

	// Copy the descriptor into a buffer that we'll analyze.
	unsigned char Descriptor[8];
	ULONG ulBytesRead;
	g_pExtensionApis->lpReadProcessMemoryRoutine(
		lDescriptorAddress,
		Descriptor,
		8,
		&ulBytesRead);

	/////////////////////////////////////////
	// Print the raw data.
	/////////////////////////////////////////

	g_pExtensionApis->lpOutputRoutine("------------------- Interrupt Gate Descriptor --------------------\r\n");

	// Print out the IDT base, index and resulting descriptor address.
	g_pExtensionApis->lpOutputRoutine("IDT base = 0x%08X, Index = 0x%02x, Descriptor @ 0x%08x\r\n", 
		lTableBase, lTableIndex, lDescriptorAddress);

	// Print out the raw descriptor data.
	g_pExtensionApis->lpOutputRoutine("%08x ", lDescriptorAddress);

	for(int i=0; i<8; i++)
	{
		g_pExtensionApis->lpOutputRoutine("%02x ", Descriptor[i]);
	}
	
	g_pExtensionApis->lpOutputRoutine("\r\n");

	/////////////////////////////////////////
	// Interpret the descriptor.
	/////////////////////////////////////////

	// Parse out the Present, DPL, System bit and X bit.
	BOOL bSegmentPresent = (Descriptor[5] & (1<<7)) == (1<<7);
	char chDPL = (Descriptor[5] >> 5) & 3; 
	BOOL bSystemSegment = (Descriptor[5] & (1<<4)) == 0;
	BOOL b32BitDescriptor = (Descriptor[5] & (1<<3)) == (1<<3);

	// Print out the interpreted descriptor information.
	g_pExtensionApis->lpOutputRoutine("Segment %s present, DPL = %d, %s segment, %s-bit descriptor\r\n", 
		bSegmentPresent ? "is" : "is not", chDPL, bSystemSegment ? "System" : "User", b32BitDescriptor ? "32" : "16");

	// Parse out the target code segment selector.
	WORD wCodeSegmentSelector = (Descriptor[3] << 1) + Descriptor[2];
	WORD wDTIndex = wCodeSegmentSelector >> 3;
	BOOL bLDT = (wCodeSegmentSelector & (1<<2)) == (1<<2);
	char chRPL = wCodeSegmentSelector & 3; 
	
	// Print out the interpreted target code selector information.
	g_pExtensionApis->lpOutputRoutine("Target code segment selector = 0x%04x (%s Index = %d, RPL = %d)\r\n", 
		wCodeSegmentSelector, bLDT ? "LDT" : "GDT", wDTIndex, chRPL);

	// Parse out the target segment offset.
	unsigned long ulTargetSegmentOffset = (Descriptor[7] << 3*8) + 
		(Descriptor[6] << 2*8) + (Descriptor[1] << 1*8) + Descriptor[0];
	
	g_pExtensionApis->lpOutputRoutine("Target code segment offset = 0x%08x\r\n", 
		ulTargetSegmentOffset);

	// Dump out the Code Segment Descriptor.
	DumpGDTOrLDTDescriptor(bLDT, wDTIndex);
}

DECLARE_API(descriptor)
{
	// These are the arguments passed in:
	HANDLE _hCurrentProcess = hCurrentProcess;
    HANDLE _hCurrentThread = hCurrentThread;
    ULONG _dwCurrentPc = dwCurrentPc;
    ULONG _dwProcessor = dwProcessor;
    PCSTR _args = args;

	// Parse out the arguments.
	// The command arguments are (in args):
	// 1: "IDT", "GDT" or "LDT".
	// 2: The index into the descriptor table.

	char szTable[128];
	long lIndex;
	sscanf(args, "%s %x", szTable, &lIndex);

	// Dump the specified descriptor table entry.
	if(_stricmp(szTable, "IDT") == 0)
	{
		DumpIDTDescriptor(lIndex);
		return;
	}
	
	if(_stricmp(szTable, "GDT") == 0)
	{
		DumpGDTOrLDTDescriptor(FALSE, lIndex);
		return;
	}

	if(_stricmp(szTable, "LDT") == 0)
	{
		DumpGDTOrLDTDescriptor(TRUE, lIndex);
		return;
	}

}

DECLARE_API(help)
{
	g_pExtensionApis->lpOutputRoutine("\r\ndescriptor: Displays a descriptor in the IDT, GDT or LDT.\r\n");
	g_pExtensionApis->lpOutputRoutine("syntax: descriptor <IDT | GDT | LDT> <Index>\r\n");
	g_pExtensionApis->lpOutputRoutine("example: descriptor IDT 2e\r\n");
}
